//Gvidas Liutus
//k00201407
//HANGMAN

//libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define noOfWords	25           
#define noOfLives	5            
#define TRUE        1           
#define FALSE       0   


//prototypes
void intro();
void gameOver();
void showStars(const size_t len);
void checkWord(char guessed, const char word[], char *a, const size_t len, unsigned int *found);
void showWords();

struct player  // structure player with name and chances for writing in to the leaderboard
{
	char name[15];
	int chances;
};

//global variables



//the main function
int main()
{	
	
	
	char *hanged[]={				//the drawing
                     "|=====|\n"
                     "      |\n"
                     "      |\n"
                     "      |\n"
                     "     ===\n",
                     "|=====|\n"
                     "O     |\n"
                     "      |\n"
                     "      |\n"
                     "     ===\n",
                     "|=====|\n"
                     "O     |\n"
                     "|     |\n"
                     "      |\n"
                     "     ===\n",
                     "|=====|\n"
                     "O     |\n"
                     "|     |\n"
                     "|     |\n"
                     "     ===\n",
                     " |=====|\n"
                     " O     |\n"
                     " |     |\n"
                    "/ \\    |\n"
                     "     ===\n"

    };
    
    char *words[] = {
                      "ZIPPERING", "BASKETBALL", "BOVVER", "BRONTOSAURUS","ELEPHANT","CHANDALIER","TERMINATOR","SOFTWARE", "DEVELOPER", "LITHUANIA", "KIMONO", "TWITTER",
                      "JAMMIEST", "FUZZIEST", "HAJJ", "BUBBLING", "BUZZER", "ZAPPED", "WOOLLINESS", "JAZZES", "HISTOGRAM", "PURPLE", "THESAURUS",
                      "WAXWING", "FOXING"
    };
	int selection=6; //selection while is not equal to 0 (EXIT) keeps on loopinng
	
	intro();
	
	while (selection!=0)
	{
	

		scanf("\n\n%d",&selection);
		
		if(selection==1)
		{
			
			int lives=5;
			struct player player1; //initialise structure ant variables
		
			
			printf("\t\tPlease enter your name:");
			scanf("%s", &player1.name);
			
			//char *n[15];
			//n[15]= name;
			if(strlen(player1.name)>15)
				{
					printf("\t\tthe user name is too long");
					printf("\n\t\tPlease enter your name:");
					scanf("%s",&player1.name);
					
					//char *n[15];
					//n[15]= &name;
				}
			else 
				{
					printf("\n\n\t\tWelcome %s",player1.name);
					
					srand((unsigned) time(NULL));
	   				unsigned short chosen_word = rand() % noOfWords;
				
					char guessed; 
	    			size_t len = strlen(words[chosen_word]); 
				    size_t i = 0;               
				    unsigned int found = FALSE; 
				    unsigned int chances = 0;   
				    
				    showStars(len);

				    
				    char *a = (char *)malloc(len + 1);
				
				    printf("\nGuess a letter: ");
				
				   
				    while(1)
				    {
				       
				        guessed = toupper(getchar());
				       
				        if(guessed != '\n')
						{
				            printf("\nGuess a letter: ");
				           
				            checkWord(guessed, words[chosen_word], a, len, &found);
				
				           
				            if(found == FALSE) 
				            {
				            	lives--;
				                if(chances >= 4) 
				                {
				                    printf("\n\n%s\n\n", hanged[chances++]); 
				                    gameOver(); 
				                   
				                }
				               
				                printf("\n\n\t\tUnfortunately, try again\n");
				                printf("\n\n%s\n\n", hanged[chances++]);
				            }
				
				            found = FALSE;
			    		}
    				}
				    
					}
	
		}
	
	/**	if(selection==2)
		{
		
		}
		
	**/	
		if(selection==3)
		{
			showWords();
			intro();
		}
			
	}
	
	
	return(0);
	getch();
	
}


void intro()
{
	int ch;
	FILE *fp;
	fp= fopen("intro.txt","r");
	ch=getc(fp);
	while(ch!=EOF)
	{
		putchar(ch);
		ch=getc(fp);
	}
	printf("\n\t\tWELCOME TO THE HANGMAN EXPERIENCE");
	printf("\n\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	printf("\n\n\n \t\tPLAY THE GAME\t\t\t1 \n \t\tView Leaderboard ***UNDER DEVELOPMENT***\t\t2 \n \t\tVIEW THE POSSIBLE WORDS\t\t3 \n \t\tEXIT\t\t\t\t0 \n\t\t________________________________");
	
}

void gameOver()
{
    printf("\n\n\t\tYou have been hanged!\n\n");
    intro();
}

void showStars(const size_t len)
{
    size_t i;
    for(i = 0; i < len; i++)
        printf(" * ");
    printf("\n\n");
}



void checkWord(char guessed, const char word[], char *a, const size_t len, unsigned int *found)
{
    size_t i;

    for(i = 0; i < len; i++)
    {
        if(guessed == word[i])
        {
            
            *(a + i) = guessed;
            *found = TRUE;
        }
        else
        {
           
            if(*(a + i) >= 65 && *(a + i) <= 90 ) ; 	//ignores the guessed letters and places * for the the rest 
            else if(*(a + i) >= 97 && *(a + i) <= 122) ; 
            else *(a + i) = '*'; 
        }
    }

    for(i = 0; i < len; i++)
    {
        printf("%c ", *(a + i)); 
    }

    if(strcmp(a, word) == 0) //when 2 strings compares to one another you win the game
    {
        printf("\n\n\t\tYou did it. Well done.\n\n");
       // writeToFile(player1);
        intro();
    }

    return;

}

void writeToFile()
{
	int ch;
	FILE *fp;
	fp= fopen("leaderboard.txt","a+");
	ch=getc(fp);
}

void showWords()
{
	int ch;
	FILE *fp;
	fp= fopen("words.txt","r");
	ch=getc(fp);
	while(ch!=EOF)
	{
		putchar(ch);
		ch=getc(fp);
	}
}

